## AWS EC2 Setup

# Bastion server configuration
Host bastion
    HostName <your-bastion-private-ip>
    User runner
    IdentityFile ~/.ssh/bastion_key
    Port 22

# Git server through bastion
Host git-server
    HostName <your-git-server-ip>
    User git
    Port 22
    ProxyCommand ssh -W %h:%p bastion
    IdentityFile ~/.ssh/id_rsa



ssh -i ./.ssh/proxy_bastion ec2-user@10.0.0.17


Host git.styl.solutions
    HostName git.styl.solutions
    User git
    Port 22
    ProxyCommand ssh -W %h:%p bastion
    IdentityFile ~/.ssh/id_rsa
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null